import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from database import get_connection
from data_processing import analyze_customer_behavior, analyze_product_relationships, generate_customer_insights, calculate_product_similarities
from recommendation_engine import get_recommendation_metrics

st.set_page_config(
    page_title="Analytics Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 E-commerce Analytics Dashboard")

# Function to load basic stats
@st.cache_data(ttl=300)
def load_basic_stats():
    conn = get_connection()
    customers_count = pd.read_sql("SELECT COUNT(*) as count FROM customers", conn)['count'][0]
    products_count = pd.read_sql("SELECT COUNT(*) as count FROM products", conn)['count'][0]
    interactions_count = pd.read_sql("SELECT COUNT(*) as count FROM interactions", conn)['count'][0]
    recommendations_count = pd.read_sql("SELECT COUNT(*) as count FROM recommendations", conn)['count'][0]
    
    # Get conversion rate
    interactions_by_type = pd.read_sql("""
        SELECT interaction_type, COUNT(*) as count 
        FROM interactions 
        GROUP BY interaction_type
    """, conn)
    
    views = interactions_by_type[interactions_by_type['interaction_type'] == 'view']['count'].sum() if 'view' in interactions_by_type['interaction_type'].values else 0
    purchases = interactions_by_type[interactions_by_type['interaction_type'] == 'purchase']['count'].sum() if 'purchase' in interactions_by_type['interaction_type'].values else 0
    
    conversion_rate = purchases / views if views > 0 else 0
    
    # Get segment distribution
    segments = pd.read_sql("""
        SELECT segment, COUNT(*) as count 
        FROM customers 
        GROUP BY segment
    """, conn)
    
    # Get category distribution
    categories = pd.read_sql("""
        SELECT category, COUNT(*) as count 
        FROM products 
        GROUP BY category
    """, conn)
    
    conn.close()
    
    return {
        "customers_count": customers_count,
        "products_count": products_count,
        "interactions_count": interactions_count,
        "recommendations_count": recommendations_count,
        "conversion_rate": conversion_rate,
        "segments": segments,
        "categories": categories
    }

# Load basic stats
basic_stats = load_basic_stats()

# Dashboard Overview
st.header("Overview")

# Key metrics
col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.metric("Total Customers", basic_stats["customers_count"])
with col2:
    st.metric("Total Products", basic_stats["products_count"])
with col3:
    st.metric("Total Interactions", basic_stats["interactions_count"])
with col4:
    st.metric("Total Recommendations", basic_stats["recommendations_count"])
with col5:
    st.metric("Conversion Rate", f"{basic_stats['conversion_rate']:.2%}")

# Segment and category distribution
col1, col2 = st.columns(2)

with col1:
    # Customer segments
    if not basic_stats["segments"].empty:
        fig = px.pie(
            basic_stats["segments"], 
            values="count", 
            names="segment", 
            title="Customer Segments Distribution",
            hole=0.4
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No customer segment data available.")

with col2:
    # Product categories
    if not basic_stats["categories"].empty:
        fig = px.bar(
            basic_stats["categories"], 
            x="category", 
            y="count", 
            title="Product Categories Distribution",
            color="count"
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No product category data available.")

# Main analytics tabs
tab1, tab2, tab3, tab4 = st.tabs(["Customer Analytics", "Product Analytics", "Recommendation Analytics", "Agent System Insights"])

with tab1:
    st.header("Customer Behavior Analytics")
    
    # Run customer behavior analysis
    if st.button("Analyze Customer Behavior"):
        with st.spinner("Analyzing customer behavior..."):
            behavior_data = analyze_customer_behavior()
            st.session_state.behavior_data = behavior_data
    
    if "behavior_data" in st.session_state:
        data = st.session_state.behavior_data
        
        # Display interaction summary
        st.subheader("Interaction Summary")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Interactions", data["interaction_count"])
        with col2:
            st.metric("Total Customers", data["customer_count"])
        with col3:
            st.metric("Total Products", data["product_count"])
        
        # Display conversion rate
        st.metric("Overall Conversion Rate", f"{data['conversion_rate']:.2%}")
        
        # Category distribution
        if data["category_distribution"]:
            st.subheader("Product Category Distribution")
            category_df = pd.DataFrame({
                "Category": list(data["category_distribution"].keys()),
                "Count": list(data["category_distribution"].values())
            })
            fig = px.bar(category_df, x="Category", y="Count", title="Interactions by Product Category", color="Count")
            st.plotly_chart(fig, use_container_width=True)
        
        # Interaction types
        if data["interaction_types"]:
            st.subheader("Interaction Types")
            interaction_df = pd.DataFrame({
                "Type": list(data["interaction_types"].keys()),
                "Count": list(data["interaction_types"].values())
            })
            fig = px.pie(interaction_df, values="Count", names="Type", title="Distribution of Interaction Types")
            st.plotly_chart(fig, use_container_width=True)
        
        # Customer segments
        if data["customer_segments"]:
            st.subheader("Customer Segments")
            segment_df = pd.DataFrame({
                "Segment": list(data["customer_segments"].keys()),
                "Count": list(data["customer_segments"].values())
            })
            fig = px.bar(segment_df, x="Segment", y="Count", title="Interactions by Customer Segment", color="Count")
            st.plotly_chart(fig, use_container_width=True)
        
        # Time analysis
        if data["time_analysis"]["hourly"]:
            st.subheader("Temporal Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Hourly distribution
                hourly_df = pd.DataFrame({
                    "Hour": list(data["time_analysis"]["hourly"].keys()),
                    "Count": list(data["time_analysis"]["hourly"].values())
                })
                hourly_df = hourly_df.sort_values("Hour")
                fig = px.line(hourly_df, x="Hour", y="Count", title="Interactions by Hour of Day", markers=True)
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Daily distribution
                daily_df = pd.DataFrame({
                    "Day": list(data["time_analysis"]["daily"].keys()),
                    "Count": list(data["time_analysis"]["daily"].values())
                })
                # Reorder days of week
                day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                daily_df["Day"] = pd.Categorical(daily_df["Day"], categories=day_order, ordered=True)
                daily_df = daily_df.sort_values("Day")
                fig = px.bar(daily_df, x="Day", y="Count", title="Interactions by Day of Week", color="Count")
                st.plotly_chart(fig, use_container_width=True)
    
    # Customer insights
    st.header("Customer Insights")
    
    if st.button("Generate Customer Insights"):
        with st.spinner("Generating customer insights..."):
            insights = generate_customer_insights()
            st.session_state.customer_insights = insights
    
    if "customer_insights" in st.session_state:
        insights = st.session_state.customer_insights
        
        # Segment insights
        if insights["segment_insights"]:
            st.subheader("Segment Insights")
            
            # Select segment to view
            segments = [insight["segment"] for insight in insights["segment_insights"]]
            selected_segment = st.selectbox("Select Segment", segments)
            
            # Display insights for selected segment
            for insight in insights["segment_insights"]:
                if insight["segment"] == selected_segment:
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Customer Count", insight["customer_count"])
                    with col2:
                        st.metric("Average Price", f"${insight['avg_price']:.2f}")
                    with col3:
                        st.metric("Conversion Rate", f"{insight['conversion_rate']:.2%}")
                    
                    # Display interaction counts
                    if insight["interaction_counts"]:
                        interaction_df = pd.DataFrame({
                            "Type": list(insight["interaction_counts"].keys()),
                            "Count": list(insight["interaction_counts"].values())
                        })
                        fig = px.pie(interaction_df, values="Count", names="Type", 
                                     title=f"Interaction Types for {selected_segment} Segment")
                        st.plotly_chart(fig, use_container_width=True)
                    
                    # Display top categories
                    st.write("**Top Categories:**")
                    for category in insight["top_categories"]:
                        st.write(f"- {category}")
                    
                    break
        
        # Demographic insights
        if insights["demographic_insights"]:
            st.subheader("Demographic Insights")
            
            # Group by demographic type
            demo_types = {}
            for insight in insights["demographic_insights"]:
                demo_type = insight["demographic"].split(":")[0].strip()
                if demo_type not in demo_types:
                    demo_types[demo_type] = []
                demo_types[demo_type].append(insight)
            
            # Create tabs for each demographic type
            demo_tabs = st.tabs(demo_types.keys())
            
            for i, (demo_type, demo_insights) in enumerate(demo_types.items()):
                with demo_tabs[i]:
                    # Create comparison dataframe
                    comparison = []
                    for insight in demo_insights:
                        comparison.append({
                            "Group": insight["demographic"].split(":")[1].strip(),
                            "Customer Count": insight["customer_count"],
                            "Average Price": insight["avg_price"],
                            "Top Categories": ", ".join(insight["top_categories"])
                        })
                    
                    # Display comparison table
                    comparison_df = pd.DataFrame(comparison)
                    st.dataframe(comparison_df, use_container_width=True)
                    
                    # Visualize customer count
                    fig = px.bar(comparison_df, x="Group", y="Customer Count", 
                                title=f"Customer Count by {demo_type}", color="Customer Count")
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Visualize average price
                    fig = px.bar(comparison_df, x="Group", y="Average Price", 
                                title=f"Average Price by {demo_type}", color="Average Price")
                    st.plotly_chart(fig, use_container_width=True)
        
        # Value insights
        if insights["value_insights"]:
            st.subheader("Customer Value Insights")
            
            # Display value insights
            for insight in insights["value_insights"]:
                st.write(f"### {insight['value_group']}")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Customer Count", insight["customer_count"])
                    st.metric("Average Purchase Value", f"${insight['avg_purchase_value']:.2f}")
                
                with col2:
                    st.write("**Top Categories:**")
                    for category in insight["top_categories"]:
                        st.write(f"- {category}")
                    
                    if insight["segment_distribution"]:
                        st.write("**Segment Distribution:**")
                        segment_df = pd.DataFrame({
                            "Segment": list(insight["segment_distribution"].keys()),
                            "Count": list(insight["segment_distribution"].values())
                        })
                        fig = px.pie(segment_df, values="Count", names="Segment", title="Segment Distribution")
                        st.plotly_chart(fig, use_container_width=True)
                
                st.divider()

with tab2:
    st.header("Product Analytics")
    
    # Product relationship analysis
    st.subheader("Product Relationships")
    
    if st.button("Analyze Product Relationships"):
        with st.spinner("Analyzing product relationships..."):
            product_rels = analyze_product_relationships()
            st.session_state.product_relationships = product_rels
    
    if "product_relationships" in st.session_state:
        rels = st.session_state.product_relationships
        
        # Co-viewed products
        if rels["co_viewed_products"]:
            st.subheader("Frequently Co-viewed Products")
            
            # Create network visualization
            nodes = set()
            edges = []
            
            for rel in rels["co_viewed_products"]:
                product1 = rel["product1"]["name"]
                product2 = rel["product2"]["name"]
                count = rel["count"]
                
                nodes.add(product1)
                nodes.add(product2)
                edges.append((product1, product2, count))
            
            # Prepare data for network graph
            node_list = list(nodes)
            edge_list = pd.DataFrame(edges, columns=["source", "target", "value"])
            
            # Display as table for now (networkx is not directly available in Streamlit)
            st.write("Top co-viewed product pairs:")
            for rel in rels["co_viewed_products"][:10]:
                st.write(f"- {rel['product1']['name']} and {rel['product2']['name']} (viewed together {rel['count']} times)")
            
            # Display top co-viewed pairs
            co_viewed_df = pd.DataFrame([
                {
                    "Product Pair": f"{rel['product1']['name']} & {rel['product2']['name']}",
                    "Count": rel["count"],
                    "Category 1": rel["product1"]["category"],
                    "Category 2": rel["product2"]["category"]
                }
                for rel in rels["co_viewed_products"][:10]
            ])
            
            fig = px.bar(co_viewed_df, x="Product Pair", y="Count", 
                        title="Top Co-viewed Product Pairs",
                        color="Count")
            fig.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
        
        # Co-purchased products
        if rels["co_purchased_products"]:
            st.subheader("Frequently Co-purchased Products")
            
            # Display top co-purchased pairs
            co_purchased_df = pd.DataFrame([
                {
                    "Product Pair": f"{rel['product1']['name']} & {rel['product2']['name']}",
                    "Count": rel["count"],
                    "Category 1": rel["product1"]["category"],
                    "Category 2": rel["product2"]["category"]
                }
                for rel in rels["co_purchased_products"][:10]
            ])
            
            fig = px.bar(co_purchased_df, x="Product Pair", y="Count", 
                        title="Top Co-purchased Product Pairs",
                        color="Count")
            fig.update_layout(xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
        
        # Category relationships
        if rels["category_relationships"]:
            st.subheader("Category Relationships")
            
            # Display category relationships
            category_df = pd.DataFrame({
                "Category Pair": list(rels["category_relationships"].keys()),
                "Strength": list(rels["category_relationships"].values())
            }).sort_values("Strength", ascending=False)
            
            fig = px.bar(category_df.head(10), x="Category Pair", y="Strength", 
                        title="Top Category Relationships",
                        color="Strength")
            st.plotly_chart(fig, use_container_width=True)
    
    # Product similarities
    st.subheader("Product Similarity Analysis")
    
    if st.button("Calculate Product Similarities"):
        with st.spinner("Calculating product similarities..."):
            similarities = calculate_product_similarities()
            st.session_state.product_similarities = similarities
    
    if "product_similarities" in st.session_state:
        similarities = st.session_state.product_similarities
        
        if similarities["similarities"]:
            # Allow selecting a product to see similar items
            conn = get_connection()
            products = pd.read_sql("SELECT id, name, category FROM products", conn)
            conn.close()
            
            selected_product_id = st.selectbox(
                "Select a Product",
                options=products["id"].tolist(),
                format_func=lambda x: f"{products[products['id'] == x]['name'].values[0]} ({products[products['id'] == x]['category'].values[0]})"
            )
            
            # Find similar products
            similar_products = [s for s in similarities["similarities"] if s["product1_id"] == selected_product_id]
            
            if similar_products:
                st.write(f"### Products Similar to {products[products['id'] == selected_product_id]['name'].values[0]}")
                
                # Display similar products
                for product in similar_products:
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.write(f"**{product['product2_name']}**")
                    with col2:
                        st.write(f"Similarity: {product['similarity_score']:.2f}")
                        st.progress(min(product['similarity_score'], 1.0))
                    st.divider()
            else:
                st.info(f"No similar products found for {products[products['id'] == selected_product_id]['name'].values[0]}")
        else:
            st.info("No product similarity data available.")
    
    # Product interaction analysis
    st.subheader("Product Interaction Analysis")
    
    # Get interaction data for products
    conn = get_connection()
    product_interactions = pd.read_sql("""
        SELECT p.id, p.name, p.category, COUNT(i.id) as interaction_count,
            SUM(CASE WHEN i.interaction_type = 'view' THEN 1 ELSE 0 END) as views,
            SUM(CASE WHEN i.interaction_type = 'add_to_cart' THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN i.interaction_type = 'purchase' THEN 1 ELSE 0 END) as purchases,
            SUM(CASE WHEN i.interaction_type = 'review' THEN 1 ELSE 0 END) as reviews
        FROM products p
        LEFT JOIN interactions i ON p.id = i.product_id
        GROUP BY p.id
        ORDER BY interaction_count DESC
    """, conn)
    conn.close()
    
    if not product_interactions.empty:
        # Add conversion rates
        product_interactions['view_to_cart'] = product_interactions['cart_adds'] / product_interactions['views']
        product_interactions['cart_to_purchase'] = product_interactions['purchases'] / product_interactions['cart_adds']
        product_interactions['view_to_purchase'] = product_interactions['purchases'] / product_interactions['views']
        
        # Replace NaNs with 0
        product_interactions = product_interactions.fillna(0)
        
        # Top products by interaction
        st.write("### Top Products by Interaction Count")
        top_products = product_interactions.head(10)
        
        fig = px.bar(top_products, x="name", y="interaction_count", 
                    color="category", title="Top 10 Products by Interaction Count")
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)
        
        # Interaction breakdown
        st.write("### Interaction Type Breakdown")
        
        selected_product_id = st.selectbox(
            "Select a Product",
            options=product_interactions["id"].tolist(),
            format_func=lambda x: f"{product_interactions[product_interactions['id'] == x]['name'].values[0]} ({product_interactions[product_interactions['id'] == x]['category'].values[0]})",
            key="interaction_product"
        )
        
        selected_product = product_interactions[product_interactions["id"] == selected_product_id].iloc[0]
        
        # Create pie chart of interaction types
        interaction_types = {
            "Views": selected_product["views"],
            "Cart Adds": selected_product["cart_adds"],
            "Purchases": selected_product["purchases"],
            "Reviews": selected_product["reviews"]
        }
        
        interaction_df = pd.DataFrame({
            "Type": list(interaction_types.keys()),
            "Count": list(interaction_types.values())
        })
        
        fig = px.pie(interaction_df, values="Count", names="Type", 
                    title=f"Interaction Breakdown for {selected_product['name']}")
        st.plotly_chart(fig, use_container_width=True)
        
        # Conversion metrics
        st.write("### Conversion Metrics")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("View to Cart Rate", f"{selected_product['view_to_cart']:.2%}")
        with col2:
            st.metric("Cart to Purchase Rate", f"{selected_product['cart_to_purchase']:.2%}")
        with col3:
            st.metric("View to Purchase Rate", f"{selected_product['view_to_purchase']:.2%}")
        
        # Category comparison
        st.write("### Category Performance Comparison")
        
        # Group by category
        category_metrics = product_interactions.groupby("category").agg({
            "interaction_count": "sum",
            "views": "sum",
            "cart_adds": "sum",
            "purchases": "sum",
            "reviews": "sum"
        }).reset_index()
        
        # Calculate category conversion rates
        category_metrics['view_to_purchase'] = category_metrics['purchases'] / category_metrics['views']
        category_metrics = category_metrics.fillna(0)
        
        # Display category metrics
        fig = px.bar(category_metrics, x="category", y="interaction_count", 
                    title="Interactions by Category", color="category")
        st.plotly_chart(fig, use_container_width=True)
        
        fig = px.bar(category_metrics, x="category", y="view_to_purchase", 
                    title="View to Purchase Conversion Rate by Category", color="view_to_purchase")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No product interaction data available.")

with tab3:
    st.header("Recommendation Analytics")
    
    # Get recommendation metrics
    if st.button("Get Recommendation Metrics"):
        with st.spinner("Collecting recommendation metrics..."):
            rec_metrics = get_recommendation_metrics()
            st.session_state.recommendation_metrics = rec_metrics
    
    if "recommendation_metrics" in st.session_state:
        metrics = st.session_state.recommendation_metrics
        
        # Algorithm counts
        if metrics["algorithm_counts"]:
            st.subheader("Recommendations by Algorithm")
            
            algo_df = pd.DataFrame(metrics["algorithm_counts"])
            
            fig = px.pie(algo_df, values="count", names="algorithm", 
                        title="Distribution of Recommendations by Algorithm")
            st.plotly_chart(fig, use_container_width=True)
        
        # Average scores
        if metrics["avg_scores"]:
            st.subheader("Average Recommendation Scores by Algorithm")
            
            scores_df = pd.DataFrame(metrics["avg_scores"])
            
            fig = px.bar(scores_df, x="algorithm", y="avg_score", 
                        title="Average Recommendation Score by Algorithm",
                        color="avg_score")
            st.plotly_chart(fig, use_container_width=True)
        
        # Segment recommendations
        if metrics["segment_recommendations"]:
            st.subheader("Recommendations by Customer Segment")
            
            segment_df = pd.DataFrame(metrics["segment_recommendations"])
            
            # Create pivot table
            segment_pivot = segment_df.pivot_table(
                index="segment",
                columns="algorithm",
                values="count",
                aggfunc="sum",
                fill_value=0
            ).reset_index()
            
            # Melt for visualization
            segment_melt = pd.melt(
                segment_pivot, 
                id_vars=["segment"], 
                var_name="algorithm", 
                value_name="count"
            )
            
            fig = px.bar(segment_melt, x="segment", y="count", color="algorithm",
                        title="Recommendations by Segment and Algorithm",
                        barmode="group")
            st.plotly_chart(fig, use_container_width=True)
        
        # Latest recommendations
        if metrics["latest_recommendations"]:
            st.subheader("Latest Recommendations")
            
            latest_df = pd.DataFrame(metrics["latest_recommendations"])
            latest_df["timestamp"] = pd.to_datetime(latest_df["timestamp"])
            
            # Display latest recommendations table
            with st.expander("View Latest Recommendations"):
                st.dataframe(
                    latest_df[["customer_name", "product_name", "algorithm", "score", "timestamp"]].sort_values("timestamp", ascending=False),
                    use_container_width=True
                )
            
            # Group by day and algorithm
            latest_df["date"] = latest_df["timestamp"].dt.date
            daily_counts = latest_df.groupby(["date", "algorithm"]).size().reset_index(name="count")
            
            fig = px.line(daily_counts, x="date", y="count", color="algorithm",
                        title="Daily Recommendation Counts by Algorithm",
                        markers=True)
            st.plotly_chart(fig, use_container_width=True)
    
    # Recommendation effectiveness analysis
    st.subheader("Recommendation Effectiveness Analysis")
    
    # Get conversion data from recommendations
    conn = get_connection()
    rec_effectiveness = pd.read_sql("""
        WITH rec_interactions AS (
            SELECT r.id as rec_id, r.customer_id, r.product_id, r.algorithm, r.score,
                i.interaction_type, i.timestamp as interaction_time, r.timestamp as rec_time
            FROM recommendations r
            LEFT JOIN interactions i ON r.customer_id = i.customer_id AND r.product_id = i.product_id
            WHERE i.timestamp > r.timestamp
        )
        SELECT algorithm, 
            COUNT(*) as total_recs,
            SUM(CASE WHEN interaction_type IS NOT NULL THEN 1 ELSE 0 END) as interacted,
            SUM(CASE WHEN interaction_type = 'view' THEN 1 ELSE 0 END) as viewed,
            SUM(CASE WHEN interaction_type = 'add_to_cart' THEN 1 ELSE 0 END) as added_to_cart,
            SUM(CASE WHEN interaction_type = 'purchase' THEN 1 ELSE 0 END) as purchased
        FROM rec_interactions
        GROUP BY algorithm
    """, conn)
    conn.close()
    
    if not rec_effectiveness.empty:
        # Calculate effectiveness metrics
        rec_effectiveness["interaction_rate"] = rec_effectiveness["interacted"] / rec_effectiveness["total_recs"]
        rec_effectiveness["view_rate"] = rec_effectiveness["viewed"] / rec_effectiveness["total_recs"]
        rec_effectiveness["purchase_rate"] = rec_effectiveness["purchased"] / rec_effectiveness["total_recs"]
        
        # Replace NaNs with 0
        rec_effectiveness = rec_effectiveness.fillna(0)
        
        # Display effectiveness metrics
        st.write("### Recommendation Effectiveness by Algorithm")
        
        fig = px.bar(rec_effectiveness, x="algorithm", y=["view_rate", "purchase_rate"], 
                    title="Recommendation Effectiveness Metrics by Algorithm",
                    barmode="group")
        st.plotly_chart(fig, use_container_width=True)
        
        # Display detailed metrics
        st.dataframe(rec_effectiveness, use_container_width=True)
    else:
        st.info("No recommendation effectiveness data available yet. This requires customers to interact with recommended products.")

with tab4:
    st.header("Agent System Insights")
    
    st.write("""
    The multi-agent AI system operates through a collaborative network of specialized agents, each with different responsibilities:
    
    - **Customer Agents:** Represent individual users and learn their preferences
    - **Product Agents:** Represent items in the catalog and track their relationships
    - **Recommendation Agent:** Coordinates the overall system and generates personalized recommendations
    """)
    
    # Agent system visualization
    st.subheader("Multi-Agent System Architecture")
    
    # Using Streamlit's graphviz functionality to create a diagram
    st.graphviz_chart('''
    digraph AgentSystem {
        rankdir=TB;
        node [shape=box, style=filled, color=lightblue];
        
        DB [label="SQLite Database", shape=cylinder, color=lightgrey];
        
        subgraph cluster_agents {
            label="Agent System";
            style=filled;
            color=lightgrey;
            
            CustomerAgents [label="Customer Agents"];
            ProductAgents [label="Product Agents"];
            RecommendationAgent [label="Recommendation Agent"];
            
            CustomerAgents -> RecommendationAgent [label="preferences\nbehavior"];
            ProductAgents -> RecommendationAgent [label="attributes\nrelationships"];
            RecommendationAgent -> CustomerAgents [label="recommendations"];
        }
        
        UI [label="Streamlit UI", shape=component, color=lightgrey];
        
        UI -> CustomerAgents [label="user interactions"];
        UI -> ProductAgents [label="product updates"];
        CustomerAgents -> DB [label="read/write"];
        ProductAgents -> DB [label="read/write"];
        RecommendationAgent -> DB [label="read/write"];
        DB -> UI [label="display data"];
    }
    ''')
    
    # Agent activity metrics
    st.subheader("Agent Activity Metrics")
    
    # Get agent activity data
    conn = get_connection()
    
    # Customer agent activity
    customer_agent_activity = pd.read_sql("""
        SELECT c.segment, COUNT(i.id) as interaction_count
        FROM customers c
        JOIN interactions i ON c.id = i.customer_id
        GROUP BY c.segment
    """, conn)
    
    # Product agent activity
    product_agent_activity = pd.read_sql("""
        SELECT p.category, COUNT(i.id) as interaction_count
        FROM products p
        JOIN interactions i ON p.id = i.product_id
        GROUP BY p.category
    """, conn)
    
    # Recommendation agent activity
    rec_agent_activity = pd.read_sql("""
        SELECT algorithm, COUNT(*) as recommendation_count
        FROM recommendations
        GROUP BY algorithm
    """, conn)
    
    conn.close()
    
    col1, col2 = st.columns(2)
    
    with col1:
        if not customer_agent_activity.empty:
            st.write("### Customer Agent Activity by Segment")
            fig = px.pie(customer_agent_activity, values="interaction_count", names="segment", 
                        title="Customer Agent Interactions by Segment")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No customer agent activity data available.")
        
        if not rec_agent_activity.empty:
            st.write("### Recommendation Agent Activity by Algorithm")
            fig = px.bar(rec_agent_activity, x="algorithm", y="recommendation_count", 
                        title="Recommendation Agent Activity by Algorithm",
                        color="recommendation_count")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No recommendation agent activity data available.")
    
    with col2:
        if not product_agent_activity.empty:
            st.write("### Product Agent Activity by Category")
            fig = px.bar(product_agent_activity, x="category", y="interaction_count", 
                        title="Product Agent Interactions by Category",
                        color="interaction_count")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No product agent activity data available.")
    
    # Agent system performance
    st.subheader("Agent System Performance")
    
    # Get data for agent performance evaluation
    conn = get_connection()
    
    # Customer segmentation accuracy
    segment_distribution = pd.read_sql("""
        SELECT segment, COUNT(*) as customer_count
        FROM customers
        GROUP BY segment
    """, conn)
    
    # Recommendation relevance
    recommendation_relevance = pd.read_sql("""
        SELECT r.algorithm, 
            AVG(r.score) as avg_score,
            COUNT(DISTINCT r.customer_id) as customer_count,
            COUNT(DISTINCT r.product_id) as product_count,
            COUNT(*) as recommendation_count
        FROM recommendations r
        GROUP BY r.algorithm
    """, conn)
    
    conn.close()
    
    col1, col2 = st.columns(2)
    
    with col1:
        if not segment_distribution.empty:
            st.write("### Customer Agent Segmentation")
            fig = px.pie(segment_distribution, values="customer_count", names="segment", 
                        title="Customer Distribution by Segment")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No customer segmentation data available.")
    
    with col2:
        if not recommendation_relevance.empty:
            st.write("### Recommendation Agent Relevance Scores")
            fig = px.bar(recommendation_relevance, x="algorithm", y="avg_score", 
                        title="Average Recommendation Relevance Score by Algorithm",
                        color="avg_score")
            st.plotly_chart(fig, use_container_width=True)
            
            # Display recommendation diversity
            st.write("### Recommendation Diversity")
            
            diversity_df = recommendation_relevance.copy()
            diversity_df["product_per_customer"] = diversity_df["product_count"] / diversity_df["customer_count"]
            
            fig = px.bar(diversity_df, x="algorithm", y="product_per_customer", 
                        title="Recommendation Diversity (Products per Customer)",
                        color="product_per_customer")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No recommendation relevance data available.")
    
    # Agent system evolution
    st.write("### System Evolution Over Time")
    st.info("The multi-agent system continuously learns from customer interactions to improve recommendations. More interaction data will improve the system's effectiveness over time.")

# Sidebar for date filtering
st.sidebar.header("Dashboard Settings")

# Date range filter (just UI, not connected since the database doesn't support it in this implementation)
st.sidebar.date_input("Start Date", value=pd.Timestamp.now() - pd.Timedelta(days=30))
st.sidebar.date_input("End Date", value=pd.Timestamp.now())

st.sidebar.write("Note: Date filtering is not active in this implementation.")

# Refresh button
if st.sidebar.button("Refresh Dashboard"):
    st.experimental_rerun()

# Additional dashboard info
st.sidebar.markdown("""
### Dashboard Information
This analytics dashboard provides insights into the e-commerce recommendation system:

- **Customer Analytics:** Understand customer behavior, segments, and purchasing patterns
- **Product Analytics:** Analyze product relationships, similarities, and performance
- **Recommendation Analytics:** Evaluate the effectiveness of different recommendation algorithms
- **Agent System Insights:** Understand how the multi-agent AI system operates

The data updates as new customer interactions and recommendations are generated.
""")

# Footer
st.markdown("---")
st.markdown("© 2023 Smart Shopping: AI-Powered E-commerce Recommendation System")
