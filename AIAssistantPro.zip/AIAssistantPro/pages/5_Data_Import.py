import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from database import get_connection
from data_import import import_customer_data, import_product_data, generate_interactions_from_history
from recommendation_engine import segment_customers

st.set_page_config(
    page_title="Data Import and Processing",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Data Import and Processing")

st.write("""
This page allows you to import customer and product data from CSV files, 
generate interactions based on customer history, and segment customers.
""")

# File upload section
st.header("Import Data")

# Data preview section
tab1, tab2 = st.tabs(["Customer Data", "Product Data"])

with tab1:
    st.subheader("Customer Data Preview")
    try:
        customer_df = pd.read_csv("attached_assets/customer_data_collection.csv")
        st.dataframe(customer_df.head(10), use_container_width=True)
        st.write(f"Total records: {len(customer_df)}")
        
        # Some statistics about the data
        st.subheader("Customer Data Statistics")
        col1, col2, col3 = st.columns(3)
        with col1:
            # Age distribution
            fig = px.histogram(customer_df, x="Age", title="Age Distribution")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Gender distribution
            gender_counts = customer_df["Gender"].value_counts().reset_index()
            gender_counts.columns = ["Gender", "Count"]
            fig = px.pie(gender_counts, values="Count", names="Gender", title="Gender Distribution")
            st.plotly_chart(fig, use_container_width=True)
        
        with col3:
            # Location distribution
            location_counts = customer_df["Location"].value_counts().reset_index()
            location_counts.columns = ["Location", "Count"]
            fig = px.bar(location_counts, x="Location", y="Count", title="Location Distribution")
            st.plotly_chart(fig, use_container_width=True)
        
        # Customer segments
        segment_counts = customer_df["Customer_Segment"].value_counts().reset_index()
        segment_counts.columns = ["Segment", "Count"]
        fig = px.pie(segment_counts, values="Count", names="Segment", title="Customer Segments")
        st.plotly_chart(fig, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error loading customer data: {str(e)}")

with tab2:
    st.subheader("Product Data Preview")
    try:
        product_df = pd.read_csv("attached_assets/product_recommendation_data.csv")
        st.dataframe(product_df.head(10), use_container_width=True)
        st.write(f"Total records: {len(product_df)}")
        
        # Some statistics about the data
        st.subheader("Product Data Statistics")
        col1, col2 = st.columns(2)
        with col1:
            # Category distribution
            category_counts = product_df["Category"].value_counts().reset_index()
            category_counts.columns = ["Category", "Count"]
            fig = px.pie(category_counts, values="Count", names="Category", title="Product Categories")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Price distribution
            fig = px.histogram(product_df, x="Price", title="Price Distribution")
            st.plotly_chart(fig, use_container_width=True)
        
        # Product ratings
        fig = px.histogram(product_df, x="Product_Rating", title="Product Rating Distribution")
        st.plotly_chart(fig, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error loading product data: {str(e)}")

# Import data section
st.header("Import Data to Database")
with st.expander("Import data to the recommendation system"):
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Import Settings")
        import_limit = st.number_input("Number of records to import (0 for all)", min_value=0, max_value=10000, value=100, step=50)
        st.caption("Note: Setting a lower number will make the import process faster.")
        
    with col2:
        st.subheader("Current Database Stats")
        # Get current database stats
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM customers")
        customer_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM products")
        product_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM interactions")
        interaction_count = cursor.fetchone()[0]
        
        conn.close()
        
        st.metric("Customers in Database", customer_count)
        st.metric("Products in Database", product_count)
        st.metric("Interactions in Database", interaction_count)
    
    # Import buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Import Customer Data", use_container_width=True):
            with st.spinner("Importing customer data..."):
                limit = None if import_limit == 0 else import_limit
                imported = import_customer_data("attached_assets/customer_data_collection.csv", limit=limit)
                st.success(f"Successfully imported {imported} customers!")
                st.rerun()
    
    with col2:
        if st.button("Import Product Data", use_container_width=True):
            with st.spinner("Importing product data..."):
                limit = None if import_limit == 0 else import_limit
                imported = import_product_data("attached_assets/product_recommendation_data.csv", limit=limit)
                st.success(f"Successfully imported {imported} products!")
                st.rerun()

    with col3:
        if st.button("Generate Interactions", use_container_width=True):
            with st.spinner("Generating interactions from customer history..."):
                interaction_count = generate_interactions_from_history()
                st.success(f"Successfully generated {interaction_count} interactions!")
                st.rerun()

# Run segmentation
st.header("Customer Segmentation")
st.write("Run the segmentation algorithm to analyze customer behavior and create meaningful segments.")

if st.button("Run Segmentation Algorithm"):
    with st.spinner("Segmenting customers based on their behavior and preferences..."):
        result = segment_customers()
        
        if result["success"]:
            st.success(f"Successfully segmented customers into {result['clusters']} segments!")
        else:
            st.error("Failed to segment customers.")

# Data processing explanation
st.header("About the Data")
st.write("""
### Customer Data
The customer dataset contains information about customers including:
- Demographics (age, gender, location)
- Browsing and purchase history
- Customer segments
- Average order value
- Seasonal and holiday preferences

### Product Data
The product dataset contains information about products including:
- Category and subcategory
- Price and brand
- Product ratings and review sentiment
- Similar products
- Seasonal and geographical relevance
- Recommendation probability

### Data Processing
When importing the data, the system:
1. Converts the CSV data into the database format
2. Generates interactions based on browsing and purchase history
3. Creates customer preference profiles
4. Builds product attribute profiles
5. Uses the data to improve recommendation algorithms
""")

# Show current data
st.header("Current Data Overview")

# Database statistics
conn = get_connection()
customers_df = pd.read_sql("SELECT * FROM customers", conn)
products_df = pd.read_sql("SELECT * FROM products", conn)
interactions_df = pd.read_sql("SELECT * FROM interactions", conn)
conn.close()

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Total Customers", len(customers_df))
with col2:
    st.metric("Total Products", len(products_df))
with col3:
    st.metric("Total Interactions", len(interactions_df))

# Customer segments
if not customers_df.empty:
    segments = customers_df["segment"].value_counts().reset_index()
    segments.columns = ["Segment", "Count"]
    
    fig = px.pie(segments, values="Count", names="Segment", title="Customer Segments in Database")
    st.plotly_chart(fig, use_container_width=True)

# Product categories
if not products_df.empty:
    categories = products_df["category"].value_counts().reset_index()
    categories.columns = ["Category", "Count"]
    
    fig = px.bar(categories, x="Category", y="Count", title="Product Categories in Database", color="Count")
    st.plotly_chart(fig, use_container_width=True)

# Interaction types
if not interactions_df.empty:
    interaction_types = interactions_df["interaction_type"].value_counts().reset_index()
    interaction_types.columns = ["Type", "Count"]
    
    fig = px.pie(interaction_types, values="Count", names="Type", title="Interaction Types in Database")
    st.plotly_chart(fig, use_container_width=True)