import streamlit as st
import pandas as pd
import plotly.express as px
from database import get_connection, add_product
import json

st.set_page_config(
    page_title="Product Catalog",
    page_icon="📦",
    layout="wide"
)

st.title("📦 Product Catalog")

# Function to load products from database
@st.cache_data(ttl=300)
def load_products():
    conn = get_connection()
    products = pd.read_sql("SELECT * FROM products", conn)
    conn.close()
    return products

# Load products
products = load_products()

# Sidebar filters
st.sidebar.header("Filters")

# Category filter
categories = ["All"] + sorted(products["category"].unique().tolist())
selected_category = st.sidebar.selectbox("Category", categories)

# Price range filter
min_price = float(products["price"].min())
max_price = float(products["price"].max())
price_range = st.sidebar.slider("Price Range", min_price, max_price, (min_price, max_price))

# Apply filters
filtered_products = products.copy()

if selected_category != "All":
    filtered_products = filtered_products[filtered_products["category"] == selected_category]

filtered_products = filtered_products[
    (filtered_products["price"] >= price_range[0]) & 
    (filtered_products["price"] <= price_range[1])
]

# Add a search box
search_term = st.sidebar.text_input("Search products")
if search_term:
    filtered_products = filtered_products[
        filtered_products["name"].str.contains(search_term, case=False) | 
        filtered_products["description"].str.contains(search_term, case=False)
    ]

# Display products count
st.write(f"Displaying {len(filtered_products)} products")

# Product list
col1, col2 = st.columns([2, 1])

with col1:
    # Display products in a table
    st.subheader("Product List")
    
    if not filtered_products.empty:
        # Format price as currency
        filtered_products_display = filtered_products.copy()
        filtered_products_display["price"] = filtered_products_display["price"].apply(lambda x: f"${x:.2f}")
        
        # Display table with select button
        selected_product = None
        
        for i, row in filtered_products_display.iterrows():
            col_a, col_b, col_c = st.columns([3, 1, 1])
            with col_a:
                st.write(f"**{row['name']}**")
                st.write(f"*{row['category']}* | {row['price']}")
            with col_b:
                if st.button("Details", key=f"details_{row['id']}"):
                    selected_product = filtered_products.iloc[i]
            with col_c:
                if st.button("View Stats", key=f"stats_{row['id']}"):
                    st.session_state.selected_product_stats = filtered_products.iloc[i]
            st.divider()
    else:
        st.info("No products match your filters.")

with col2:
    # Product details section
    st.subheader("Product Details")
    
    if "selected_product_stats" in st.session_state:
        selected_product = st.session_state.selected_product_stats
        
        # Display product details
        st.write(f"### {selected_product['name']}")
        st.write(f"**Category:** {selected_product['category']}")
        st.write(f"**Price:** ${selected_product['price']:.2f}")
        st.write(f"**Description:** {selected_product['description']}")
        
        # Parse attributes
        try:
            if isinstance(selected_product['attributes'], str):
                try:
                    attributes = json.loads(selected_product['attributes'].replace("'", "\""))
                except:
                    attributes = eval(selected_product['attributes'])
            else:
                attributes = {}
                
            if attributes:
                st.write("**Attributes:**")
                for key, value in attributes.items():
                    st.write(f"- {key}: {value}")
        except:
            st.write("No attributes found")
        
        # Product Statistics
        st.subheader("Product Statistics")
        
        # Get interaction data for this product
        conn = get_connection()
        interactions = pd.read_sql(f"""
        SELECT interaction_type, COUNT(*) as count
        FROM interactions
        WHERE product_id = {selected_product['id']}
        GROUP BY interaction_type
        """, conn)
        
        if not interactions.empty:
            # Interaction pie chart
            fig = px.pie(interactions, values='count', names='interaction_type', 
                        title=f"Interactions for {selected_product['name']}")
            st.plotly_chart(fig, use_container_width=True)
            
            # Get related products based on customer interactions
            related_products = pd.read_sql(f"""
            SELECT p.name, p.category, COUNT(i.id) as interaction_count
            FROM products p
            JOIN interactions i ON p.id = i.product_id
            WHERE i.customer_id IN (
                SELECT DISTINCT customer_id 
                FROM interactions 
                WHERE product_id = {selected_product['id']}
            )
            AND p.id != {selected_product['id']}
            GROUP BY p.id
            ORDER BY interaction_count DESC
            LIMIT 5
            """, conn)
            
            if not related_products.empty:
                st.write("**Frequently Viewed Together:**")
                st.dataframe(related_products, use_container_width=True)
        else:
            st.info("No interaction data available for this product.")
        
        conn.close()
    else:
        st.info("Select a product to view details.")

# Add a new product section
st.header("Add New Product")
with st.expander("Add a new product"):
    with st.form("add_product_form"):
        new_product_name = st.text_input("Product Name")
        
        col1, col2 = st.columns(2)
        with col1:
            new_product_category = st.selectbox("Category", sorted(products["category"].unique().tolist()))
        with col2:
            new_product_price = st.number_input("Price", min_value=0.01, value=9.99, step=0.01)
        
        new_product_description = st.text_area("Description")
        
        # Attributes as key-value pairs
        st.subheader("Attributes (optional)")
        
        attributes_container = st.container()
        num_attributes = st.number_input("Number of attributes", min_value=0, max_value=10, value=1)
        
        attributes = {}
        
        for i in range(num_attributes):
            col1, col2 = st.columns(2)
            with col1:
                key = st.text_input(f"Attribute {i+1} Key", key=f"attr_key_{i}")
            with col2:
                value = st.text_input(f"Attribute {i+1} Value", key=f"attr_val_{i}")
            
            if key and value:
                attributes[key] = value
        
        submit_button = st.form_submit_button("Add Product")
        
        if submit_button:
            if not new_product_name:
                st.error("Product name is required")
            else:
                # Add product to database
                product_id = add_product(
                    name=new_product_name,
                    category=new_product_category,
                    price=new_product_price,
                    description=new_product_description,
                    attributes=str(attributes)
                )
                
                st.success(f"Product '{new_product_name}' added successfully!")
                st.experimental_rerun()

# Product Analytics Section
st.header("Product Analytics")

# Category distribution
st.subheader("Products by Category")
category_counts = products["category"].value_counts().reset_index()
category_counts.columns = ["Category", "Count"]

fig = px.bar(category_counts, x="Category", y="Count", 
             title="Product Distribution by Category",
             color="Count")
st.plotly_chart(fig, use_container_width=True)

# Price distribution
st.subheader("Price Distribution")
fig = px.histogram(products, x="price", nbins=20, 
                  title="Product Price Distribution",
                  labels={"price": "Price ($)"})
st.plotly_chart(fig, use_container_width=True)

# Top interacted products
conn = get_connection()
top_products = pd.read_sql("""
SELECT p.name, p.category, COUNT(i.id) as interaction_count
FROM products p
JOIN interactions i ON p.id = i.product_id
GROUP BY p.id
ORDER BY interaction_count DESC
LIMIT 10
""", conn)
conn.close()

if not top_products.empty:
    st.subheader("Top 10 Products by Interaction Count")
    fig = px.bar(top_products, x="name", y="interaction_count", 
                color="category",
                title="Top Products by Customer Interaction",
                labels={"name": "Product Name", "interaction_count": "Interaction Count"})
    fig.update_layout(xaxis_tickangle=-45)
    st.plotly_chart(fig, use_container_width=True)
