import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from database import get_connection, add_customer, update_customer_segment
from data_processing import analyze_customer_behavior
import json

st.set_page_config(
    page_title="Customer Profiles",
    page_icon="👤",
    layout="wide"
)

st.title("👤 Customer Profiles")

# Function to load customers from database
@st.cache_data(ttl=300)
def load_customers():
    conn = get_connection()
    customers = pd.read_sql("SELECT * FROM customers", conn)
    conn.close()
    return customers

# Load customers
customers = load_customers()

# Sidebar filters
st.sidebar.header("Filters")

# Segment filter
segments = ["All"] + sorted(customers["segment"].unique().tolist())
selected_segment = st.sidebar.selectbox("Segment", segments)

# Location filter
locations = ["All"] + sorted(customers["location"].unique().tolist())
selected_location = st.sidebar.selectbox("Location", locations)

# Apply filters
filtered_customers = customers.copy()

if selected_segment != "All":
    filtered_customers = filtered_customers[filtered_customers["segment"] == selected_segment]

if selected_location != "All":
    filtered_customers = filtered_customers[filtered_customers["location"] == selected_location]

# Add a search box
search_term = st.sidebar.text_input("Search customers")
if search_term:
    filtered_customers = filtered_customers[
        filtered_customers["name"].str.contains(search_term, case=False) | 
        filtered_customers["email"].str.contains(search_term, case=False)
    ]

# Display customers count
st.write(f"Displaying {len(filtered_customers)} customers")

# Customers list
col1, col2 = st.columns([2, 1])

with col1:
    # Display customers in a table
    st.subheader("Customer List")
    
    if not filtered_customers.empty:
        # Display table with select button
        for i, row in filtered_customers.iterrows():
            col_a, col_b, col_c = st.columns([3, 1, 1])
            with col_a:
                st.write(f"**{row['name']}**")
                st.write(f"*{row['email']}* | {row['segment']}")
            with col_b:
                if st.button("Details", key=f"details_{row['id']}"):
                    st.session_state.selected_customer = filtered_customers.iloc[i]
            with col_c:
                if st.button("View Behavior", key=f"behavior_{row['id']}"):
                    st.session_state.selected_customer_behavior = filtered_customers.iloc[i]
            st.divider()
    else:
        st.info("No customers match your filters.")

with col2:
    # Customer details section
    st.subheader("Customer Details")
    
    if "selected_customer" in st.session_state:
        selected_customer = st.session_state.selected_customer
        
        # Display customer details
        st.write(f"### {selected_customer['name']}")
        st.write(f"**Email:** {selected_customer['email']}")
        st.write(f"**Segment:** {selected_customer['segment']}")
        st.write(f"**Age:** {selected_customer['age']}")
        st.write(f"**Gender:** {selected_customer['gender']}")
        st.write(f"**Location:** {selected_customer['location']}")
        
        # Parse preferences
        try:
            if isinstance(selected_customer['preferences'], str):
                try:
                    preferences = json.loads(selected_customer['preferences'].replace("'", "\""))
                except:
                    preferences = eval(selected_customer['preferences'])
            else:
                preferences = {}
                
            if preferences:
                st.write("**Preferences:**")
                for key, value in preferences.items():
                    st.write(f"- {key}: {value}")
        except:
            st.write("No preferences found")
        
        # Customer Statistics
        st.subheader("Customer Statistics")
        
        # Get interaction data for this customer
        conn = get_connection()
        interactions = pd.read_sql(f"""
        SELECT interaction_type, COUNT(*) as count
        FROM interactions
        WHERE customer_id = {selected_customer['id']}
        GROUP BY interaction_type
        """, conn)
        
        if not interactions.empty:
            # Interaction pie chart
            fig = px.pie(interactions, values='count', names='interaction_type', 
                        title=f"Interactions for {selected_customer['name']}")
            st.plotly_chart(fig, use_container_width=True)
            
            # Get product categories this customer has interacted with
            categories = pd.read_sql(f"""
            SELECT p.category, COUNT(i.id) as count
            FROM interactions i
            JOIN products p ON i.product_id = p.id
            WHERE i.customer_id = {selected_customer['id']}
            GROUP BY p.category
            ORDER BY count DESC
            """, conn)
            
            if not categories.empty:
                # Category bar chart
                fig = px.bar(categories, x='category', y='count',
                            title=f"Categories Interacted With",
                            labels={'category': 'Category', 'count': 'Interaction Count'})
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No interaction data available for this customer.")
        
        # Recommendations section
        recommendations = pd.read_sql(f"""
        SELECT r.*, p.name as product_name, p.category, p.price
        FROM recommendations r
        JOIN products p ON r.product_id = p.id
        WHERE r.customer_id = {selected_customer['id']}
        ORDER BY r.score DESC
        LIMIT 5
        """, conn)
        
        if not recommendations.empty:
            st.subheader("Top Recommendations")
            for _, rec in recommendations.iterrows():
                st.write(f"**{rec['product_name']}** ({rec['category']}) - ${rec['price']:.2f}")
                st.progress(float(rec['score']))
                st.write(f"*Algorithm: {rec['algorithm']}*")
        else:
            st.info("No recommendations available for this customer.")
        
        conn.close()
    else:
        st.info("Select a customer to view details.")

# Customer behavior analysis section
if "selected_customer_behavior" in st.session_state:
    st.header(f"Behavior Analysis: {st.session_state.selected_customer_behavior['name']}")
    
    # Get customer behavior analysis
    with st.spinner("Analyzing customer behavior..."):
        behavior_data = analyze_customer_behavior(st.session_state.selected_customer_behavior['id'])
    
    if behavior_data:
        # Display interaction summary
        st.subheader("Interaction Summary")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Interactions", behavior_data["interaction_count"])
        with col2:
            st.metric("Conversion Rate", f"{behavior_data['conversion_rate']:.2%}")
        
        # Display customer journey if available
        if "customer_journey" in behavior_data:
            journey = behavior_data["customer_journey"]
            
            # Category preferences
            st.subheader("Category Preferences")
            if journey["category_preferences"]:
                categories = pd.DataFrame.from_dict(
                    journey["category_preferences"], 
                    orient='index', 
                    columns=['count']
                ).reset_index()
                categories.columns = ['Category', 'Count']
                
                fig = px.bar(categories, x='Category', y='Count',
                            title="Category Preferences",
                            color='Count')
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No category preferences data available.")
            
            # Price range
            st.subheader("Price Range Behavior")
            price_range = journey["price_range"]
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Min Price", f"${price_range['min']:.2f}")
            with col2:
                st.metric("Max Price", f"${price_range['max']:.2f}")
            with col3:
                st.metric("Average Price", f"${price_range['avg']:.2f}")
            
            # Journey timeline
            st.subheader("Customer Journey Timeline")
            if journey["journey_events"]:
                events = pd.DataFrame(journey["journey_events"])
                events['timestamp'] = pd.to_datetime(events['timestamp'])
                events = events.sort_values('timestamp')
                
                # Timeline chart
                fig = go.Figure()
                
                # Add events to timeline
                for i, event in events.iterrows():
                    fig.add_trace(go.Scatter(
                        x=[event['timestamp']],
                        y=[event['interaction_type']],
                        mode='markers',
                        marker=dict(
                            size=12,
                            symbol='circle',
                            color={
                                'view': 'blue',
                                'add_to_cart': 'orange',
                                'purchase': 'green',
                                'review': 'purple'
                            }.get(event['interaction_type'], 'gray')
                        ),
                        name=f"{event['interaction_type']} - {event['product_name']}"
                    ))
                
                # Add hover information
                for i, event in events.iterrows():
                    fig.add_trace(go.Scatter(
                        x=[event['timestamp']],
                        y=[event['interaction_type']],
                        mode='markers',
                        marker=dict(opacity=0),
                        showlegend=False,
                        hoverinfo='text',
                        hovertext=f"Time: {event['timestamp']}<br>Action: {event['interaction_type']}<br>Product: {event['product_name']}<br>Category: {event['category']}<br>Price: ${event['price']:.2f}"
                    ))
                
                fig.update_layout(
                    title="Customer Journey Timeline",
                    xaxis_title="Time",
                    yaxis_title="Interaction Type",
                    hovermode="closest"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # List view of events
                with st.expander("View Journey Details"):
                    events_display = events.copy()
                    events_display['price'] = events_display['price'].apply(lambda x: f"${x:.2f}")
                    events_display['timestamp'] = events_display['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')
                    st.dataframe(events_display[['timestamp', 'interaction_type', 'product_name', 'category', 'price']], use_container_width=True)
            else:
                st.info("No journey events available.")
    else:
        st.error("Could not analyze customer behavior.")

# Add a new customer section
st.header("Add New Customer")
with st.expander("Add a new customer"):
    with st.form("add_customer_form"):
        new_customer_name = st.text_input("Customer Name")
        new_customer_email = st.text_input("Email")
        
        col1, col2 = st.columns(2)
        with col1:
            new_customer_age = st.number_input("Age", min_value=1, max_value=120, value=30)
        with col2:
            new_customer_gender = st.selectbox("Gender", ["Male", "Female", "Other"])
        
        new_customer_location = st.selectbox("Location", sorted(customers["location"].unique().tolist()))
        new_customer_segment = st.selectbox("Segment", sorted(customers["segment"].unique().tolist()))
        
        # Preferences as JSON
        st.subheader("Preferences (optional)")
        
        # Favorite categories
        available_categories = pd.read_sql("SELECT DISTINCT category FROM products", get_connection())['category'].tolist()
        favorite_categories = st.multiselect("Favorite Categories", available_categories)
        
        # Price sensitivity
        price_sensitivity = st.select_slider("Price Sensitivity", options=["Low", "Medium", "High"])
        
        # Combine preferences
        preferences = {
            "favorite_categories": favorite_categories,
            "price_sensitivity": price_sensitivity
        }
        
        submit_button = st.form_submit_button("Add Customer")
        
        if submit_button:
            if not new_customer_name or not new_customer_email:
                st.error("Customer name and email are required")
            else:
                # Add customer to database
                customer_id = add_customer(
                    name=new_customer_name,
                    email=new_customer_email,
                    age=new_customer_age,
                    gender=new_customer_gender,
                    location=new_customer_location,
                    segment=new_customer_segment,
                    preferences=str(preferences)
                )
                
                st.success(f"Customer '{new_customer_name}' added successfully!")
                st.experimental_rerun()

# Customer Analytics Section
st.header("Customer Analytics")

# Segment distribution
st.subheader("Customers by Segment")
segment_counts = customers["segment"].value_counts().reset_index()
segment_counts.columns = ["Segment", "Count"]

fig = px.pie(segment_counts, values="Count", names="Segment", 
             title="Customer Distribution by Segment")
st.plotly_chart(fig, use_container_width=True)

# Location distribution
st.subheader("Customers by Location")
location_counts = customers["location"].value_counts().reset_index()
location_counts.columns = ["Location", "Count"]

fig = px.bar(location_counts, x="Location", y="Count", 
             title="Customer Distribution by Location",
             color="Count")
st.plotly_chart(fig, use_container_width=True)

# Age distribution
st.subheader("Age Distribution")
fig = px.histogram(customers, x="age", nbins=20, 
                  title="Customer Age Distribution",
                  labels={"age": "Age"})
st.plotly_chart(fig, use_container_width=True)

# Gender distribution
st.subheader("Customers by Gender")
gender_counts = customers["gender"].value_counts().reset_index()
gender_counts.columns = ["Gender", "Count"]

fig = px.pie(gender_counts, values="Count", names="Gender", 
             title="Customer Distribution by Gender")
st.plotly_chart(fig, use_container_width=True)

# Customer Segmentation Tool
st.header("Customer Segmentation Tool")
with st.expander("Run Customer Segmentation"):
    from recommendation_engine import segment_customers
    
    if st.button("Run Segmentation Algorithm"):
        with st.spinner("Segmenting customers..."):
            result = segment_customers()
            
            if result["success"]:
                st.success(f"Successfully segmented customers into {result['clusters']} segments!")
                st.info("The database has been updated with new customer segments.")
                st.warning("Please refresh the page to see the updated segments.")
            else:
                st.error("Failed to segment customers.")
