import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from database import get_connection, save_recommendation
from agents import agent_system
from recommendation_engine import evaluate_recommendations
import json

st.set_page_config(
    page_title="Recommendations",
    page_icon="🔮",
    layout="wide"
)

st.title("🔮 Recommendations Engine")

# Function to load customers and products
@st.cache_data(ttl=300)
def load_data():
    conn = get_connection()
    customers = pd.read_sql("SELECT * FROM customers", conn)
    products = pd.read_sql("SELECT * FROM products", conn)
    conn.close()
    return customers, products

# Load data
customers, products = load_data()

# Main layout with tabs
tab1, tab2, tab3 = st.tabs(["Generate Recommendations", "Test Algorithms", "Algorithm Details"])

with tab1:
    st.header("Generate Recommendations")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Select Customer")
        # Customer selection
        selected_customer_id = st.selectbox(
            "Customer",
            options=customers["id"].tolist(),
            format_func=lambda x: f"{customers[customers['id'] == x]['name'].values[0]} (ID: {x})"
        )
        
        # Algorithm selection
        algorithm = st.radio(
            "Recommendation Algorithm",
            options=["hybrid", "collaborative", "content", "popularity"],
            index=0
        )
        
        # Number of recommendations
        num_recommendations = st.slider("Number of Recommendations", min_value=1, max_value=20, value=10)
        
        # Generate button
        if st.button("Generate Recommendations"):
            with st.spinner("Generating recommendations..."):
                recommendations = agent_system.get_recommendations(
                    customer_id=selected_customer_id,
                    algorithm=algorithm,
                    limit=num_recommendations
                )
                
                st.session_state.current_recommendations = recommendations
                st.session_state.selected_customer_id = selected_customer_id
                st.session_state.selected_algorithm = algorithm

    with col2:
        st.subheader("Recommendation Results")
        
        if "current_recommendations" in st.session_state:
            recs = st.session_state.current_recommendations
            customer_name = customers[customers["id"] == st.session_state.selected_customer_id]["name"].values[0]
            algorithm_name = st.session_state.selected_algorithm
            
            st.write(f"Recommendations for **{customer_name}** using **{algorithm_name.capitalize()} Algorithm**")
            
            if recs:
                # Get product details for the recommendations
                conn = get_connection()
                product_ids = [rec["product_id"] for rec in recs]
                product_ids_str = ",".join([str(pid) for pid in product_ids])
                recommended_products = pd.read_sql(f"""
                SELECT * FROM products WHERE id IN ({product_ids_str})
                """, conn)
                conn.close()
                
                # Display recommendations
                for rec in recs:
                    product_info = recommended_products[recommended_products["id"] == rec["product_id"]]
                    if not product_info.empty:
                        product = product_info.iloc[0]
                        
                        col_a, col_b = st.columns([3, 1])
                        with col_a:
                            st.write(f"### {product['name']}")
                            st.write(f"**Category:** {product['category']}")
                            st.write(f"**Price:** ${float(product['price']):.2f}")
                            
                            # Parse attributes
                            try:
                                if isinstance(product['attributes'], str):
                                    attributes = json.loads(product['attributes'].replace("'", "\""))
                                    if attributes:
                                        st.write("**Attributes:**")
                                        for key, value in attributes.items():
                                            st.write(f"- {key}: {value}")
                            except:
                                pass
                        
                        with col_b:
                            st.write("**Match Score:**")
                            st.progress(rec["score"])
                            st.write(f"Score: {rec['score']:.2f}")
                        
                        st.divider()
                
                # Visualize recommendations
                st.subheader("Recommendation Distribution")
                
                # By category
                categories = []
                for rec in recs:
                    product_info = recommended_products[recommended_products["id"] == rec["product_id"]]
                    if not product_info.empty:
                        categories.append({
                            "category": product_info.iloc[0]["category"],
                            "score": rec["score"]
                        })
                
                if categories:
                    category_df = pd.DataFrame(categories)
                    category_summary = category_df.groupby("category").agg(
                        avg_score=("score", "mean"),
                        count=("score", "count")
                    ).reset_index()
                    
                    fig = px.bar(category_summary, x="category", y="count", 
                                 color="avg_score", color_continuous_scale="Viridis",
                                 title="Recommended Products by Category",
                                 labels={"category": "Category", "count": "Number of Products", "avg_score": "Average Match Score"})
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No recommendations generated. Try a different algorithm or customer.")
        else:
            st.info("Generate recommendations to see results.")

with tab2:
    st.header("Test and Compare Algorithms")
    
    st.write("""
    Compare how different recommendation algorithms perform for a specific customer.
    This helps to understand which algorithm provides the most relevant recommendations.
    """)
    
    # Customer selection for testing
    test_customer_id = st.selectbox(
        "Select Customer for Testing",
        options=customers["id"].tolist(),
        format_func=lambda x: f"{customers[customers['id'] == x]['name'].values[0]} (ID: {x})",
        key="test_customer"
    )
    
    if st.button("Run Algorithm Comparison"):
        with st.spinner("Evaluating algorithms..."):
            evaluation = evaluate_recommendations(test_customer_id)
            st.session_state.algorithm_evaluation = evaluation
    
    if "algorithm_evaluation" in st.session_state:
        eval_data = st.session_state.algorithm_evaluation
        
        # Display customer info
        st.subheader(f"Evaluation for {eval_data['customer_name']} (Segment: {eval_data['segment']})")
        st.write(f"Total interaction count: {eval_data['interaction_count']}")
        
        # Display algorithm evaluation metrics
        st.subheader("Algorithm Comparison")
        
        # Create metrics dataframe
        metrics = []
        for algo, scores in eval_data['evaluation'].items():
            metrics.append({
                "Algorithm": algo.capitalize(),
                "Viewed Overlap": scores["viewed_overlap"],
                "Cart Overlap": scores["cart_overlap"],
                "Purchased Overlap": scores["purchased_overlap"],
                "Category Relevance": scores["category_relevance"],
                "Overall Score": scores["overall_score"]
            })
        
        metrics_df = pd.DataFrame(metrics)
        
        # Display metrics table
        st.dataframe(metrics_df, use_container_width=True)
        
        # Visualize overall scores
        fig = px.bar(metrics_df, x="Algorithm", y="Overall Score", 
                    color="Overall Score", title="Algorithm Performance Comparison",
                    labels={"Algorithm": "Algorithm", "Overall Score": "Performance Score"})
        st.plotly_chart(fig, use_container_width=True)
        
        # Show top recommendations from each algorithm
        st.subheader("Top Recommendations by Algorithm")
        
        algorithms = list(eval_data['recommendations'].keys())
        selected_algo = st.selectbox("Select Algorithm to View", algorithms, format_func=lambda x: x.capitalize())
        
        if selected_algo in eval_data['recommendations']:
            recs = eval_data['recommendations'][selected_algo]
            
            if recs:
                # Get product details
                conn = get_connection()
                product_ids = [rec["product_id"] for rec in recs]
                product_ids_str = ",".join([str(pid) for pid in product_ids])
                recommended_products = pd.read_sql(f"""
                SELECT * FROM products WHERE id IN ({product_ids_str})
                """, conn)
                conn.close()
                
                for rec in recs[:5]:  # Show top 5
                    product_info = recommended_products[recommended_products["id"] == rec["product_id"]]
                    if not product_info.empty:
                        product = product_info.iloc[0]
                        
                        col_a, col_b = st.columns([3, 1])
                        with col_a:
                            st.write(f"**{product['name']}** ({product['category']})")
                            st.write(f"Price: ${float(product['price']):.2f}")
                        
                        with col_b:
                            st.progress(rec["score"])
                            st.write(f"Score: {rec['score']:.2f}")
                        
                        st.divider()
            else:
                st.info(f"No recommendations generated with {selected_algo} algorithm.")
        else:
            st.info("No recommendations available.")

with tab3:
    st.header("Recommendation Algorithms Explained")
    
    st.write("""
    This recommendation system uses multiple algorithms to generate personalized product suggestions.
    Each algorithm has different strengths and works best for different scenarios.
    """)
    
    # Algorithm explanations
    algo_tabs = st.tabs(["Hybrid", "Collaborative Filtering", "Content-Based", "Popularity-Based"])
    
    with algo_tabs[0]:
        st.subheader("Hybrid Algorithm")
        st.write("""
        The hybrid approach combines results from multiple recommendation algorithms to provide the most 
        comprehensive recommendations. It works by:
        
        1. Gathering recommendations from collaborative filtering (40% weight)
        2. Gathering recommendations from content-based filtering (40% weight)
        3. Gathering recommendations from popularity-based recommendations (20% weight)
        4. Combining and normalizing scores across all algorithms
        
        **Best for:** Most customers, as it balances all approaches and compensates for weaknesses in individual algorithms.
        
        **Works well when:** You want the most balanced recommendations that consider both customer behavior patterns and product attributes.
        """)
        
        st.image("https://miro.medium.com/v2/resize:fit:1400/1*gLt2H9FD6V5YTrJwE9D0Bg.png")
    
    with algo_tabs[1]:
        st.subheader("Collaborative Filtering")
        st.write("""
        Collaborative filtering recommends products based on the behavior of similar customers. It works by:
        
        1. Building a matrix of customer-product interactions
        2. Finding customers with similar interaction patterns
        3. Recommending products that similar customers have interacted with
        
        **Best for:** Customers with established interaction history and in situations where "customers like you also liked..."
        
        **Works well when:** You have sufficient interaction data and want to discover new, potentially unexpected items.
        """)
        
        st.image("https://miro.medium.com/v2/resize:fit:1400/1*QvhetbVVWFZ6DqYmAYiLUw.png")
    
    with algo_tabs[2]:
        st.subheader("Content-Based Filtering")
        st.write("""
        Content-based filtering recommends products similar to those the customer has shown interest in. It works by:
        
        1. Analyzing attributes of products the customer has interacted with
        2. Creating a customer preference profile based on these attributes
        3. Matching this profile with other products in the catalog
        
        **Best for:** Providing recommendations based on product features and attributes that match customer preferences.
        
        **Works well when:** You have rich product metadata and want to recommend items with similar characteristics.
        """)
        
        st.image("https://miro.medium.com/v2/resize:fit:1400/1*UVehSiTjs0EnPKNEzf4yug.png")
    
    with algo_tabs[3]:
        st.subheader("Popularity-Based")
        st.write("""
        Popularity-based recommendations suggest the most popular products across all customers. It works by:
        
        1. Counting interaction frequencies for all products
        2. Weighting different interaction types (views, purchases, etc.)
        3. Recommending products with the highest weighted count
        
        **Best for:** New customers with no interaction history or as a fallback when other algorithms lack data.
        
        **Works well when:** You need a simple, reliable approach that doesn't require personalization.
        """)
        
        st.image("https://miro.medium.com/v2/resize:fit:1400/1*71A3GkHQSXtU6eCLlzTXPQ.jpeg")
    
    # Implementation details
    st.subheader("Technical Implementation")
    
    st.write("""
    The recommendation system is implemented using a multi-agent AI framework where:
    
    - **Customer Agents** represent individual users and track their preferences, behaviors, and interaction patterns
    - **Product Agents** represent items in the catalog and their attributes, popularity, and relationships
    - **Recommendation Agent** coordinates between customer and product agents to generate personalized recommendations
    
    The system continuously learns from new interactions to improve recommendation quality over time.
    """)
    
    # Implementation diagram
    st.graphviz_chart('''
    digraph RecommendationSystem {
        rankdir=LR;
        node [shape=box, style=filled, color=lightblue];
        
        Customer [label="Customer Agent"];
        Product [label="Product Agent"];
        Recommendation [label="Recommendation Agent"];
        Database [label="SQLite Database"];
        
        Customer -> Recommendation [label="Preferences & History"];
        Product -> Recommendation [label="Attributes & Popularity"];
        Recommendation -> Customer [label="Personalized Recommendations"];
        
        Customer -> Database [label="Store Interactions"];
        Database -> Customer [label="Load Behavior"];
        Product -> Database [label="Store Metadata"];
        Database -> Product [label="Load Features"];
        Recommendation -> Database [label="Save Recommendations"];
    }
    ''')

# Sidebar for additional actions
st.sidebar.header("Recommendation Tools")

# Bulk recommendation generation
with st.sidebar.expander("Bulk Recommendation Generation"):
    st.write("Generate recommendations for multiple customers at once.")
    
    # Select customers for bulk generation
    selected_segment = st.selectbox(
        "Select Customer Segment",
        options=["All"] + sorted(customers["segment"].unique().tolist())
    )
    
    bulk_algorithm = st.selectbox(
        "Algorithm",
        options=["hybrid", "collaborative", "content", "popularity"],
        index=0
    )
    
    if st.button("Generate Bulk Recommendations"):
        if selected_segment == "All":
            bulk_customers = customers
        else:
            bulk_customers = customers[customers["segment"] == selected_segment]
        
        with st.spinner(f"Generating recommendations for {len(bulk_customers)} customers..."):
            progress_bar = st.progress(0)
            
            recommendations_count = 0
            for i, (_, customer) in enumerate(bulk_customers.iterrows()):
                # Generate recommendations for this customer
                recs = agent_system.get_recommendations(
                    customer_id=customer["id"],
                    algorithm=bulk_algorithm,
                    limit=10
                )
                
                if recs:
                    recommendations_count += len(recs)
                
                # Update progress
                progress_bar.progress((i + 1) / len(bulk_customers))
            
            st.success(f"Generated {recommendations_count} recommendations for {len(bulk_customers)} customers!")

# Real-time recommendation simulation
with st.sidebar.expander("Real-time Recommendation Simulation"):
    st.write("Simulate a customer browsing products and see recommendations update in real-time.")
    
    # Select customer for simulation
    sim_customer_id = st.selectbox(
        "Select Customer",
        options=customers["id"].tolist(),
        format_func=lambda x: f"{customers[customers['id'] == x]['name'].values[0]} (ID: {x})",
        key="sim_customer"
    )
    
    # Select product to interact with
    sim_product_id = st.selectbox(
        "Select Product to Interact With",
        options=products["id"].tolist(),
        format_func=lambda x: f"{products[products['id'] == x]['name'].values[0]} (Category: {products[products['id'] == x]['category'].values[0]})"
    )
    
    # Interaction type
    sim_interaction = st.selectbox(
        "Interaction Type",
        options=["view", "add_to_cart", "purchase", "review"]
    )
    
    # Additional details for the interaction
    if sim_interaction == "review":
        sim_rating = st.slider("Rating", min_value=1, max_value=5, value=4)
        sim_comment = st.text_input("Review Comment", value="Good product!")
        sim_details = {"rating": sim_rating, "comment": sim_comment}
    elif sim_interaction == "purchase":
        sim_quantity = st.slider("Quantity", min_value=1, max_value=10, value=1)
        sim_details = {"quantity": sim_quantity}
    else:
        sim_details = {}
    
    if st.button("Simulate Interaction"):
        with st.spinner("Recording interaction and updating recommendations..."):
            # Record the interaction
            agent_system.record_interaction(
                customer_id=sim_customer_id,
                product_id=sim_product_id,
                interaction_type=sim_interaction,
                details=sim_details
            )
            
            # Generate new recommendations
            updated_recs = agent_system.get_recommendations(
                customer_id=sim_customer_id,
                algorithm="hybrid",
                limit=5
            )
            
            st.success(f"Recorded {sim_interaction} interaction for customer ID {sim_customer_id}!")
            
            # Display updated recommendations
            st.subheader("Updated Recommendations")
            
            if updated_recs:
                # Get product details
                conn = get_connection()
                product_ids = [rec["product_id"] for rec in updated_recs]
                product_ids_str = ",".join([str(pid) for pid in product_ids])
                recommended_products = pd.read_sql(f"""
                SELECT * FROM products WHERE id IN ({product_ids_str})
                """, conn)
                conn.close()
                
                for rec in updated_recs:
                    product_info = recommended_products[recommended_products["id"] == rec["product_id"]]
                    if not product_info.empty:
                        product = product_info.iloc[0]
                        
                        st.write(f"**{product['name']}** - Match Score: {rec['score']:.2f}")
            else:
                st.info("No updated recommendations available.")
